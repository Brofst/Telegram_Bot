TOKEN = "5164225198:AAFvIojlVx0DLpmwMCkwnRM3nnSDIxWkZsE"
keys={
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB'
}